# Aloha
Aloha provides users an easy way to blow off some steam during this stressful COVID-19 epidemic. Our application filters through thousands of book, film, and quote and recommends users a new choice daily. Included in this repository are the XCode files necessary to build this app.
